package com.example.todo.data;

import java.io.Serializable;

public class UserBean implements Serializable {
    //    private String userID;
    //    private String token;
    private String userName;
    private Integer todoNum;

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public Integer getTodoNum() {
        return todoNum;
    }
    public void setTodoNum(Integer todoNum) {
        this.todoNum = todoNum;
    }
}
