package com.example.todo.data;
import java.io.Serializable;

public class TodoBean implements Serializable {
    private String title;
    private String detail;
    private String weight;
    private String id;
    private Boolean done;
    // protected Date createTime;
    public String getWeight() {
        return weight;
    }
    public String getDetail() {
        return detail;
    }
    public String getTitle() {
        return title;
    }
    public String getId() {
        return id;
    }
    public Boolean getDone() {
        return done;
    }
    public void setDetail(String detail) {
        this.detail = detail;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setWeight(String weight) {
        this.weight = weight;
    }
    public void setId(String id) {
        this.id = id;
    }
    public void setDone(Boolean done) {
        this.done = done;
    }
}
