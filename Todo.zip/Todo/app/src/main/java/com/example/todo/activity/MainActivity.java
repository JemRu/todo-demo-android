package com.example.todo.activity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.todo.DataCenter;
import com.example.todo.R;
import com.example.todo.data.TodoItem;
import com.example.todo.TodoListAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String userName;
    private ArrayList<TodoItem> todoList;
    private RecyclerView recyclerView;
    private FloatingActionButton btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler_view_todo);
        btnAdd = findViewById(R.id.btn_add);
    }

    @Override
    protected void onResume() {
        super.onResume();
        initData();
        // todo
        initListener();
        Log.d("MainActivity","--------------onResume here--------------");
    }

    private void initData() {
        userName = DataCenter.getInstance().getUserName();
        todoList = new ArrayList<>();
        todoList = DataCenter.getInstance().getTodoItems();
        // todo
        LinearLayoutManager layoutManager= new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));
        // todo
        TodoListAdapter adapter = new TodoListAdapter(todoList);
        recyclerView.setAdapter(adapter);
    }
    // todo
    private void initListener() {
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToDetailActivity();
            }
        });
    }
    private void goToDetailActivity() {
        Intent intent = new Intent();
        int id = -1;
        intent.putExtra("id",id);
        intent.setClass(MainActivity.this, DetailActivity.class);
        startActivity(intent);
    }
}