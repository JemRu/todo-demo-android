package com.example.todo.activity;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.todo.DataCenter;
import com.example.todo.R;
import com.example.todo.data.TodoItem;
import com.google.android.material.button.MaterialButton;

public class DetailActivity extends AppCompatActivity {
    EditText inptTitle,inptDetail,inptWeight;
    MaterialButton btnSave;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        ActionBar actionBar = this.getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        btnSave = findViewById(R.id.btn_save);
        inptTitle = findViewById(R.id.input_title);
        inptDetail = findViewById(R.id.input_details);
        inptWeight = findViewById(R.id.input_weight);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Intent intent = getIntent();
        int index = intent.getIntExtra("id", -1);
        initData(index);
        initListener(index);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home)
        {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initData(int index) {
        if (index != -1) {
            TodoItem item = DataCenter.getInstance().getTodoItem(index);
            inptTitle.setText(item.getTitle());
            inptDetail.setText(item.getDetail());
            inptWeight.setText(item.getWeight());
        }
    }
    private void initListener(int index) {
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toast.makeText(DetailActivity.this,  DataCenter.getInstance().getTodoBean().getTitle()+ " : " + DataCenter.getInstance().getTodoBean().getDetail()+ " : ", Toast.LENGTH_SHORT).show();
                if(index == -1) {
                    DataCenter.getInstance().addTodoItem();
                } else {
                    DataCenter.getInstance().saveTodoItem(index);
                }
                finish();
            }
        });
        inptTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.toString().isEmpty()) {
                    return;
                }
                DataCenter.getInstance().getTodoBean().setTitle(s.toString());
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.toString().isEmpty()) {
                    return;
                }
                DataCenter.getInstance().getTodoBean().setTitle(editable.toString());
            }
        });
        inptDetail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.toString().isEmpty()) {
                    return;
                }
                DataCenter.getInstance().getTodoBean().setDetail(s.toString());
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.toString().isEmpty()) {
                    return;
                }
                DataCenter.getInstance().getTodoBean().setDetail(editable.toString());
            }
        });
        inptWeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.toString().isEmpty()) {
                    return;
                }
                DataCenter.getInstance().getTodoBean().setWeight(s.toString());
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.toString().isEmpty()) {
                    return;
                }
                DataCenter.getInstance().getTodoBean().setWeight(editable.toString());
            }
        });
    }
}