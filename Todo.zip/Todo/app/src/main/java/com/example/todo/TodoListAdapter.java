package com.example.todo;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.todo.activity.DetailActivity;
import com.example.todo.data.TodoItem;

import java.util.ArrayList;
import static com.example.todo.app.MainApplication.getContext;


public class TodoListAdapter extends RecyclerView.Adapter<TodoListAdapter. ViewHolder> {
    private ArrayList<TodoItem> todoItemList;
    // , TodoAdapterInterface someHandler
    public TodoListAdapter(ArrayList<TodoItem> itemList) {
        todoItemList = itemList;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        View itemView;
        TextView itemTitle;
        TextView itemWeight;
        RadioButton itemStatus;
        ImageView itemDelete;
        public ViewHolder(View view) {
            super(view);
            itemView = view;
            itemTitle = view.findViewById(R.id.text_todo_title);
            itemWeight = view.findViewById(R.id.text_todo_weight);
            itemStatus = view.findViewById(R.id.radio_todo_status);
            itemDelete = view.findViewById(R.id.img_todo_delete);
        }
    }
    @NonNull

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_item, parent, false);
        final ViewHolder holder = new ViewHolder(view);

        holder.itemTitle.setOnClickListener(viewTitle -> {
            int position = holder.getAdapterPosition();
            TodoItem item = todoItemList.get(position);
            Intent intent = new Intent();
            intent.putExtra("id",Integer.parseInt(item.getId()));
            intent.setClass(viewTitle.getContext(), DetailActivity.class);
            viewTitle.getContext().startActivity(intent);
            // Toast.makeText(view.getContext(), "你点击了View"+ item.getId(), Toast.LENGTH_SHORT).show();
        });
        holder.itemStatus.setOnClickListener(viewS -> {
            int position = holder.getAdapterPosition();
            TodoItem item = todoItemList.get(position);
            boolean flag = item.getDone();
            holder.itemStatus.setChecked(!flag);
            item.setDone(!flag);
            // Toast.makeText(viewS.getContext(), "你点击了Radio: "+ flag, Toast.LENGTH_SHORT).show();
            if (!flag) {
                holder.itemTitle.setTextColor(ContextCompat.getColor(getContext(), R.color.gray));
                holder.itemWeight.setTextColor(ContextCompat.getColor(getContext(), R.color.gray));
            } else {
                holder.itemTitle.setTextColor(ContextCompat.getColor(getContext(), R.color.black));
                holder.itemWeight.setTextColor(ContextCompat.getColor(getContext(), R.color.black));
            }
            DataCenter.getInstance().getTodoBean().setDone(!flag);
            DataCenter.getInstance().saveTodoStatus(Integer.parseInt(item.getId()));
        });
        holder.itemDelete.setOnClickListener(viewD -> {
            int position = holder.getAdapterPosition();
            TodoItem item = todoItemList.get(position);
            // Toast.makeText(viewD.getContext(), "你试图删除: "+item.getId()+" , 想挺美 !", Toast.LENGTH_SHORT).show();
            todoItemList.remove(position);
            DataCenter.getInstance().deleteTodoItem(position, todoItemList);
            notifyDataSetChanged();
            // DataCenter.getInstance().test(0);
        });

        return holder;
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TodoItem item = todoItemList.get(position);
        holder.itemTitle.setText(item.getTitle());
        holder.itemWeight.setText(item.getWeight());
        int pos = holder.getAdapterPosition();
        boolean flag = todoItemList.get(pos).getDone();
        if(flag) {
            holder.itemTitle.setTextColor(ContextCompat.getColor(getContext(), R.color.gray));
            holder.itemWeight.setTextColor(ContextCompat.getColor(getContext(), R.color.gray));
        }
        holder.itemStatus.setChecked(item.getDone());
    }
    @Override
    public int getItemCount() {
        return todoItemList.size();
    }
}