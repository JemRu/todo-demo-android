package com.example.todo;
import android.content.Context;
import android.content.SharedPreferences;
import com.example.todo.app.MainApplication;
import com.example.todo.data.TodoBean;
import com.example.todo.data.TodoItem;
import com.example.todo.data.UserBean;

import java.util.ArrayList;

// 全局单例 数据共享与存储
public final class DataCenter {
    private static DataCenter dataCenter;
    private static final Object LOCK = new Object();

    private UserBean userBean;
    // todo
    private TodoBean todoBean = new TodoBean();
    private ArrayList<TodoItem> todoList;

    private DataCenter() {
        initUser();
        initTodo();
    }
    // init dataCenter
    public static DataCenter getInstance() {
        if (dataCenter == null) {
            synchronized (LOCK) {
                if (dataCenter == null) {
                    dataCenter = new DataCenter();
                }
            }
        }
        return dataCenter;
    }
    // init userInfo from SharedPreferences
    private void initUser() {
        SharedPreferences dataSP = MainApplication.getContext().getSharedPreferences("User", Context.MODE_PRIVATE);
        UserBean user = new UserBean();
        user.setUserName(dataSP.getString("userName", "Jem"));
        user.setTodoNum(dataSP.getInt("todoNum", 0));
        this.userBean = user;
    }
    // init todoItems from SharedPreferences
    private void initTodo() {
        SharedPreferences dataSP = MainApplication.getContext().getSharedPreferences("User", Context.MODE_PRIVATE);
        todoList = new ArrayList<>();
        int size = this.userBean.getTodoNum();
        for(int i = 0; i < size; i++) {
            todoBean.setId(dataSP.getString("id_"+i, ""));
            if (!todoBean.getId().equals("-1")) {
                todoBean.setTitle(dataSP.getString("title_"+i,"never used SP"));
                todoBean.setDetail(dataSP.getString("detail_"+i,"never used SP"));
                todoBean.setWeight(dataSP.getString("weight_"+i,"2"));
                todoBean.setDone(dataSP.getBoolean("done_"+i,false));
                TodoItem item = new TodoItem();
                item.setId(todoBean.getId());
                item.setTitle(todoBean.getTitle());
                item.setDetail(todoBean.getDetail());
                item.setWeight(todoBean.getWeight());
                item.setDone(todoBean.getDone());
                todoList.add(item);
            } else {
                size += 1;
            }
        }
    }
    // add item
    public void addTodoItem() {
        SharedPreferences.Editor editor = MainApplication.getContext().getSharedPreferences("User", Context.MODE_PRIVATE).edit();
        int index = todoList.size();
        int num = index+1;
        todoBean.setId(""+index);
        editor.putString("title_"+index, todoBean.getTitle());
        editor.putString("detail_"+index, todoBean.getDetail());
        editor.putString("weight_"+index, todoBean.getWeight());
        editor.putBoolean("done_"+index, false);
        editor.putString("id_"+index, todoBean.getId());
        editor.putInt("todoNum",num);
        editor.apply();
    }
    // update item
    public void saveTodoItem(int index) {
        SharedPreferences.Editor editor = MainApplication.getContext().getSharedPreferences("User", Context.MODE_PRIVATE).edit();
        editor.putString("title_"+index, todoBean.getTitle());
        editor.putString("detail_"+index, todoBean.getDetail());
        editor.putString("weight_"+index, todoBean.getWeight());
        editor.apply();
    }
    //update item status
    public void saveTodoStatus(int index){
        SharedPreferences.Editor editor = MainApplication.getContext().getSharedPreferences("User", Context.MODE_PRIVATE).edit();
        editor.putBoolean("done_"+index,todoBean.getDone());
        editor.apply();
    }
    // delete item
    public void deleteTodoItem(int index, ArrayList<TodoItem> updateItems) {
        SharedPreferences.Editor editor = MainApplication.getContext().getSharedPreferences("User", Context.MODE_PRIVATE).edit();
        int num = updateItems.size();
        editor.remove("id_"+num);
        editor.remove("title_"+num);
        editor.remove("detail_"+num);
        editor.remove("weight_"+num);
        editor.remove("done_"+num);
        editor.putInt("todoNum",num);
        for (int i=index; i<num ;i++) {
            editor.putString("title_"+index, updateItems.get(i).getTitle());
            editor.putString("detail_"+index, updateItems.get(i).getDetail());
            editor.putString("weight_"+index, updateItems.get(i).getWeight());
            editor.putBoolean("done_"+index, updateItems.get(i).getDone());
            editor.putString("id_"+index, ""+index);
        }
        editor.apply();
    }

    public void test(int index) {
        SharedPreferences.Editor editor = MainApplication.getContext().getSharedPreferences("User", Context.MODE_PRIVATE).edit();
        editor.remove("id_-1");
        editor.remove("title_-1");
        editor.remove("detail_-1");
        editor.remove("weight_-1");
        editor.remove("done_-1");
        // editor.putInt("todoNum",2);
        editor.apply();
    }

    public String getUserName() {
        return userBean.getUserName();
    }
    public ArrayList<TodoItem> getTodoItems() {
        initUser();
        initTodo();
        return todoList;
    }
    public TodoItem getTodoItem(int index) {
        initUser();
        initTodo();
        return todoList.get(index);
    }
    public TodoBean getTodoBean() {
        return todoBean;
    }

}
