package com.example.todo.data;

public class TodoItem {

    private String title;
    private String detail;
    private String weight;
    private String id;
    private Boolean done;

    public TodoItem() {
        this.title = "";
        this.detail = "";
        this.weight = "";
        this.id = "";
        this.done = false;
    }
    public String getWeight() {
        return weight;
    }
    public String getDetail() {
        return detail;
    }
    public String getTitle() {
        return title;
    }
    public String getId() {
        return id;
    }
    public Boolean getDone() {
        return done;
    }
    public void setDetail(String detail) {
        this.detail = detail;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setWeight(String weight) {
        this.weight = weight;
    }
    public void setId(String id) {
        this.id = id;
    }
    public void setDone(Boolean done) {
        this.done = done;
    }
}
