package com.example.todo;
import android.os.Looper;
import android.os.Message;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;
import com.example.todo.app.MainApplication;

public class UIHandler extends Thread {
    Handler uiHandler;

    @Override
    public void run() {
        super.run();
        Looper.prepare();
        uiHandler = new Handler(Looper.getMainLooper()){
            @Override
            public void handleMessage(Message msg) {
                if(msg.what == 0x110) {
                    Toast.makeText(MainApplication.getContext(),"go to detail page",Toast.LENGTH_SHORT).show();
                }
                if(msg.what == 0x111) {
                    Toast.makeText(MainApplication.getContext(),"add new item",Toast.LENGTH_SHORT).show();
                }
                if(msg.what == 0x112) {
                    Toast.makeText(MainApplication.getContext(),"update item",Toast.LENGTH_SHORT).show();
                }
                if(msg.what == 0x113) {
                    Toast.makeText(MainApplication.getContext(),"delete item",Toast.LENGTH_SHORT).show();
                }
            }
        };
        Looper.loop();
    }
}
